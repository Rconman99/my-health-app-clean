// 📄 Component: MultiWeekPlanner.js (Refined: Picker + Plan Suggestions)

import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const plans = [
  { weeks: 4, label: '4 Week Plan', suggestion: 'Good for short-term goals, mini cuts, or habit resets.' },
  { weeks: 6, label: '6 Week Plan', suggestion: 'Ideal for structured strength programs or focused athletic prep.' },
  { weeks: 8, label: '8 Week Plan', suggestion: 'Best for transformations, endurance building, or goal-driven phases.' },
];

const MultiWeekPlanner = () => {
  const [selectedPlan, setSelectedPlan] = useState(plans[1]);
  const [plan, setPlan] = useState({});
  const navigation = useNavigation();

  const handleWeekSelect = (weekIndex) => {
    navigation.navigate('WeeklyPlanner', {
      weekNumber: weekIndex + 1,
      existingPlan: plan[weekIndex] || {},
      onSave: (updatedWeek) => {
        setPlan((prev) => ({ ...prev, [weekIndex]: updatedWeek }));
      },
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>📆 Build Your Training Plan</Text>
      <Text style={styles.sub}>Select how many weeks you'd like to plan:</Text>

      {plans.map((item) => (
        <TouchableOpacity
          key={item.weeks}
          style={[styles.planCard, selectedPlan.weeks === item.weeks && styles.planActive]}
          onPress={() => setSelectedPlan(item)}
        >
          <Text style={styles.planLabel}>{item.label}</Text>
          <Text style={styles.suggestion}>{item.suggestion}</Text>
        </TouchableOpacity>
      ))}

      <Text style={styles.sub}>📅 Tap a week to customize workouts:</Text>
      {Array.from({ length: selectedPlan.weeks }).map((_, i) => (
        <TouchableOpacity key={i} style={styles.weekCard} onPress={() => handleWeekSelect(i)}>
          <Text style={styles.weekTitle}>Week {i + 1}</Text>
          <Text style={styles.weekStatus}>
            {plan[i] ? '✅ Planned' : '➕ Tap to Plan Week'}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  sub: {
    fontSize: 16,
    marginVertical: 12,
  },
  planCard: {
    padding: 14,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    marginBottom: 12,
  },
  planActive: {
    backgroundColor: '#007bff',
  },
  planLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  suggestion: {
    fontSize: 14,
    marginTop: 6,
    color: '#666',
  },
  weekCard: {
    backgroundColor: '#f7f7f7',
    padding: 16,
    borderRadius: 10,
    marginBottom: 12,
  },
  weekTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  weekStatus: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
});

export default MultiWeekPlanner;
