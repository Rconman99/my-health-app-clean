import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Button,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { askGemini } from '../utils/gemini';

const SuggestionsScreen = () => {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const getSuggestions = async () => {
    if (!input.trim()) return;
    setLoading(true);
    const result = await askGemini(input);
    setResponse(result);
    setLoading(false);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>AI Suggestions</Text>

      <TextInput
        style={styles.input}
        placeholder="Ask something like: 'Create a 4-day push-pull workout plan...'"
        value={input}
        onChangeText={setInput}
        multiline
      />

      <Button title="Ask Gemini" onPress={getSuggestions} />

      {loading ? (
        <ActivityIndicator style={{ marginTop: 20 }} size="large" color="#007bff" />
      ) : (
        <Text style={styles.output}>{response}</Text>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  output: {
    marginTop: 20,
    fontSize: 16,
    lineHeight: 24,
  },
});

export default SuggestionsScreen;