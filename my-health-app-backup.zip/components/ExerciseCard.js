// 📄 Component: ExerciseCard.js (Fixed Rounds Input Deletion Bug)

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Vibration,
  Switch,
  FlatList,
  Alert
} from 'react-native';
import exerciseLibrary from '../exerciseLibrary';

const formatTime = (seconds) => {
  if (!seconds || isNaN(seconds)) return '';
  const sec = parseInt(seconds);
  if (sec < 60) return `${sec} sec`;
  const min = Math.floor(sec / 60);
  const rem = sec % 60;
  return `${min}:${rem.toString().padStart(2, '0')} min`;
};

const ExerciseCard = ({ exercise, index, onChange, onRemove, onComplete }) => {
  const [isCompleted, setIsCompleted] = useState(false);
  const [search, setSearch] = useState('');
  const [customName, setCustomName] = useState('');
  const [timer, setTimer] = useState(null);
  const [countdown, setCountdown] = useState(null);

  const handleFieldChange = (field, value) => {
    onChange(index, { ...exercise, [field]: value });
  };

  const updateWeightsArray = (rounds) => {
    const num = Number(rounds);
    if (!isNaN(num) && num > 0) {
      const newWeights = Array.from({ length: num }, (_, i) => exercise.weights?.[i] || '');
      handleFieldChange('weights', newWeights);
    }
  };

  useEffect(() => {
    updateWeightsArray(exercise.rounds || 1);
  }, [exercise.rounds]);

  const handleComplete = () => {
    setIsCompleted(true);
    onComplete(index);
    if (exercise.useTimer) {
      const restTime = parseInt(exercise.customRestTime || exercise.restTime || 0);
      if (!isNaN(restTime) && restTime > 0) {
        setCountdown(restTime);
      }
    }
  };

  useEffect(() => {
    if (countdown === 0) {
      if (exercise.useTimer && !exercise.mute) {
        Vibration.vibrate(500);
        Alert.alert('Rest Complete', 'Time to move to the next set!');
      }
      clearInterval(timer);
    }
    if (countdown > 0) {
      const interval = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
      setTimer(interval);
      return () => clearInterval(interval);
    }
  }, [countdown]);

  const predefinedTimes = [30, 45, 60, 90, 120, 180, 240, 300, 360];
  const filteredLibrary = exerciseLibrary.filter((ex) =>
    ex.name.toLowerCase().includes(search.toLowerCase())
  );

  const addFromLibrary = (item) => {
    handleFieldChange('name', item.name);
    setSearch('');
  };

  const renderWeightsByRound = () => {
    const rounds = Number(exercise.rounds || 1);
    return Array.from({ length: rounds }, (_, i) => (
      <TextInput
        key={i}
        style={styles.input}
        placeholder={`Weight for Round ${i + 1}`}
        keyboardType="numeric"
        value={exercise.weights?.[i] || ''}
        onChangeText={(text) => {
          const updated = [...(exercise.weights || [])];
          updated[i] = text.replace(/[^0-9.]/g, '');
          handleFieldChange('weights', updated);
        }}
      />
    ));
  };

  return (
    <ScrollView style={styles.card} keyboardShouldPersistTaps="handled">
      <TextInput
        style={styles.input}
        placeholder="Search global workouts..."
        value={search}
        onChangeText={setSearch}
      />
      {search.length > 0 && (
        <FlatList
          data={filteredLibrary}
          keyExtractor={(item) => item.name}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => addFromLibrary(item)}>
              <Text style={styles.resultItem}>{item.emoji} {item.name}</Text>
            </TouchableOpacity>
          )}
          style={styles.resultList}
        />
      )}

      <TextInput
        style={styles.input}
        placeholder="Or custom workout name"
        value={customName}
        onChangeText={setCustomName}
        onSubmitEditing={() => {
          if (customName.trim()) {
            handleFieldChange('name', customName);
            setCustomName('');
          }
        }}
      />

      <Text style={styles.label}>Workout: {exercise.name}</Text>

      <TextInput
        style={styles.input}
        placeholder="Reps"
        keyboardType="numeric"
        value={exercise.reps}
        onChangeText={(text) => handleFieldChange('reps', text.replace(/[^0-9]/g, ''))}
      />

      <TextInput
        style={styles.input}
        placeholder="Rounds"
        keyboardType="numeric"
        value={exercise.rounds?.toString() || ''}
        onChangeText={(text) => {
          if (text === '') {
            handleFieldChange('rounds', '');
            handleFieldChange('weights', []);
          } else {
            const parsed = parseInt(text);
            if (!isNaN(parsed)) handleFieldChange('rounds', parsed);
          }
        }}
      />

      {renderWeightsByRound()}

      <TextInput
        style={styles.input}
        placeholder="Notes or experience"
        value={exercise.notes}
        onChangeText={(text) => handleFieldChange('notes', text)}
      />

      <View style={styles.switchRow}>
        <Text style={styles.label}>Use Rest Timer?</Text>
        <Switch
          value={exercise.useTimer ?? true}
          onValueChange={(val) => handleFieldChange('useTimer', val)}
        />
      </View>

      {exercise.useTimer && (
        <>
          <FlatList
            horizontal
            data={predefinedTimes}
            keyExtractor={(item) => item.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => handleFieldChange('restTime', item.toString())}>
                <Text style={styles.restItem}>{formatTime(item)}</Text>
              </TouchableOpacity>
            )}
            style={styles.restList}
          />

          <TextInput
            style={styles.input}
            placeholder="Custom Rest Time in Secs"
            keyboardType="numeric"
            value={exercise.customRestTime || ''}
            onChangeText={(text) => handleFieldChange('customRestTime', text.replace(/[^0-9]/g, ''))}
          />

          <View style={styles.switchRow}>
            <Text style={styles.label}>Mute Notifications?</Text>
            <Switch
              value={exercise.mute ?? false}
              onValueChange={(val) => handleFieldChange('mute', val)}
            />
          </View>
        </>
      )}

      <View style={styles.actions}>
        <TouchableOpacity style={styles.completeButton} onPress={handleComplete}>
          <Text style={styles.completeText}>✓</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.removeButton} onPress={() => onRemove(index)}>
          <Text style={styles.removeText}>🗑️</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    maxHeight: 1200,
  },
  label: {
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 8,
    marginBottom: 10,
  },
  resultItem: {
    padding: 6,
    fontSize: 16,
  },
  resultList: {
    maxHeight: 120,
    marginBottom: 8,
  },
  restItem: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: '#eee',
    borderRadius: 6,
    marginHorizontal: 4,
  },
  restList: {
    marginBottom: 8,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  completeButton: {
    backgroundColor: '#28a745',
    padding: 10,
    borderRadius: 6,
  },
  removeButton: {
    backgroundColor: '#dc3545',
    padding: 10,
    borderRadius: 6,
  },
  completeText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  removeText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default ExerciseCard;
