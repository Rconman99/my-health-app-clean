// 📄 Component: DiscoverScreen.js (Fixed VirtualizedList Warning)

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import exerciseLibrary from '../exerciseLibrary';

const GROUPS = [
  'All',
  'Leg Day',
  'Chest Day',
  'Back Day',
  'Shoulders',
  'Arms',
  'Core',
  'CrossFit',
  'Cardio',
  'Mobility',
];

const DiscoverScreen = ({ navigation, route }) => {
  const [search, setSearch] = useState('');
  const [selectedGroup, setSelectedGroup] = useState('All');

  const filteredList = exerciseLibrary.filter((exercise) => {
    const inGroup = selectedGroup === 'All' || exercise.category === selectedGroup;
    const matchesSearch =
      exercise.name.toLowerCase().includes(search.toLowerCase()) ||
      (exercise.tags || []).some((tag) => tag.toLowerCase().includes(search.toLowerCase()));
    return inGroup && matchesSearch;
  });

  const handleSelect = (item) => {
    if (route.params?.onSelectExercise) {
      route.params.onSelectExercise({
        name: item.name,
        reps: '',
        rounds: 1,
        weights: [''],
        notes: '',
        useTimer: true,
        superset: '',
      });
    }
    navigation.goBack();
  };

  const handleAddAllFromGroup = () => {
    if (!route.params?.onSelectExercise) return;
    filteredList.forEach((item) => {
      route.params.onSelectExercise({
        name: item.name,
        reps: '',
        rounds: 1,
        weights: [''],
        notes: '',
        useTimer: true,
        superset: '',
      });
    });
    navigation.goBack();
  };

  const renderHeader = () => (
    <View style={{ padding: 16 }}>
      <Text style={styles.header}>🧭 Discover Workouts</Text>

      <TextInput
        style={styles.search}
        placeholder="Search workouts, tags..."
        value={search}
        onChangeText={setSearch}
      />

      <View style={styles.groupScroll}>
        <FlatList
          horizontal
          data={GROUPS}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.groupTab, selectedGroup === item && styles.groupTabActive]}
              onPress={() => setSelectedGroup(item)}
            >
              <Text style={selectedGroup === item ? styles.groupTabTextActive : styles.groupTabText}>
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {selectedGroup !== 'All' && (
        <TouchableOpacity style={styles.bulkAddButton} onPress={handleAddAllFromGroup}>
          <Text style={styles.bulkAddText}>➕ Add All {selectedGroup} Exercises</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <FlatList
      data={filteredList}
      keyExtractor={(item) => item.name}
      renderItem={({ item }) => (
        <TouchableOpacity style={styles.card} onPress={() => handleSelect(item)}>
          <Text style={styles.cardText}>{item.emoji} {item.name}</Text>
          <Text style={styles.tagText}>{item.category} • {item.difficulty}</Text>
        </TouchableOpacity>
      )}
      ListHeaderComponent={renderHeader}
      contentContainerStyle={{ paddingBottom: 80 }}
    />
  );
};

const styles = StyleSheet.create({
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  search: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 8,
    marginBottom: 12,
  },
  groupScroll: {
    marginBottom: 16,
  },
  groupTab: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 8,
  },
  groupTabActive: {
    backgroundColor: '#007bff',
  },
  groupTabText: {
    fontSize: 14,
    color: '#333',
  },
  groupTabTextActive: {
    color: '#fff',
    fontWeight: '600',
  },
  bulkAddButton: {
    backgroundColor: '#28a745',
    padding: 10,
    borderRadius: 6,
    marginBottom: 12,
  },
  bulkAddText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#f9f9f9',
    padding: 12,
    borderRadius: 8,
    marginHorizontal: 16,
    marginBottom: 10,
  },
  cardText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  tagText: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
});

export default DiscoverScreen;
