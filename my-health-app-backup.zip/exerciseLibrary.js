// utils/exerciseLibrary.js

const exerciseLibrary = [
  // --- Strength (Bodyweight) ---
  {
    name: 'Push-Up',
    emoji: '💪',
    category: 'Strength',
    type: 'Bodyweight',
    muscleGroup: 'Chest',
    fitnessLevel: 'Beginner',
    equipment: 'None',
  },
  {
    name: 'Pull-Up',
    emoji: '🧗',
    category: 'Strength',
    type: 'Bodyweight',
    muscleGroup: 'Back',
    fitnessLevel: 'Intermediate',
    equipment: 'Pull-Up Bar',
  },
  {
    name: 'Air Squat',
    emoji: '🏋️',
    category: 'Strength',
    type: 'Bodyweight',
    muscleGroup: 'Legs',
    fitnessLevel: 'Beginner',
    equipment: 'None',
  },
  {
    name: 'Plank',
    emoji: '🪵',
    category: 'Core',
    type: 'Bodyweight',
    muscleGroup: 'Core',
    fitnessLevel: 'Beginner',
    equipment: 'None',
  },

  // --- Strength (Weighted) ---
  {
    name: 'Barbell Bench Press',
    emoji: '🏋️‍♂️',
    category: 'Strength',
    type: 'Weighted',
    muscleGroup: 'Chest',
    fitnessLevel: 'Intermediate',
    equipment: 'Barbell',
  },
  {
    name: 'Deadlift',
    emoji: '⚰️',
    category: 'Strength',
    type: 'Weighted',
    muscleGroup: 'Back',
    fitnessLevel: 'Advanced',
    equipment: 'Barbell',
  },
  {
    name: 'Dumbbell Shoulder Press',
    emoji: '🏋️',
    category: 'Strength',
    type: 'Weighted',
    muscleGroup: 'Shoulders',
    fitnessLevel: 'Intermediate',
    equipment: 'Dumbbells',
  },
  {
    name: 'Goblet Squat',
    emoji: '🥇',
    category: 'Strength',
    type: 'Weighted',
    muscleGroup: 'Legs',
    fitnessLevel: 'Beginner',
    equipment: 'Dumbbell/Kettlebell',
  },

  // --- Mobility ---
  {
    name: 'World’s Greatest Stretch',
    emoji: '🧘‍♂️',
    category: 'Mobility',
    type: 'Stretch',
    muscleGroup: 'Full Body',
    fitnessLevel: 'All',
    equipment: 'None',
  },
  {
    name: 'Cat-Cow',
    emoji: '🐱🐮',
    category: 'Mobility',
    type: 'Stretch',
    muscleGroup: 'Spine',
    fitnessLevel: 'All',
    equipment: 'None',
  },

  // --- Functional & CrossFit ---
  {
    name: 'Burpee',
    emoji: '🔥',
    category: 'Functional',
    type: 'Bodyweight',
    muscleGroup: 'Full Body',
    fitnessLevel: 'Intermediate',
    equipment: 'None',
  },
  {
    name: 'Wall Ball',
    emoji: '🏐',
    category: 'CrossFit',
    type: 'Weighted',
    muscleGroup: 'Legs/Shoulders',
    fitnessLevel: 'Intermediate',
    equipment: 'Medicine Ball',
  },
  {
    name: 'Kettlebell Swing',
    emoji: '🏋️‍♀️',
    category: 'Functional',
    type: 'Weighted',
    muscleGroup: 'Glutes',
    fitnessLevel: 'Intermediate',
    equipment: 'Kettlebell',
  },

  // --- Conditioning ---
  {
    name: 'Jump Rope',
    emoji: '🔁',
    category: 'Cardio',
    type: 'Bodyweight',
    muscleGroup: 'Full Body',
    fitnessLevel: 'All',
    equipment: 'Jump Rope',
  },
  {
    name: 'Assault Bike',
    emoji: '🚴‍♂️',
    category: 'Cardio',
    type: 'Machine',
    muscleGroup: 'Full Body',
    fitnessLevel: 'All',
    equipment: 'Assault Bike',
  },
  {
    name: 'Rowing',
    emoji: '🚣',
    category: 'Cardio',
    type: 'Machine',
    muscleGroup: 'Back/Legs',
    fitnessLevel: 'All',
    equipment: 'Rowing Machine',
  },

  // --- Recovery ---
  {
    name: 'Foam Roll Quads',
    emoji: '🧽',
    category: 'Recovery',
    type: 'Roller',
    muscleGroup: 'Quads',
    fitnessLevel: 'All',
    equipment: 'Foam Roller',
  },
  {
    name: 'Lying Hamstring Stretch',
    emoji: '🧘‍♀️',
    category: 'Recovery',
    type: 'Stretch',
    muscleGroup: 'Hamstrings',
    fitnessLevel: 'All',
    equipment: 'Band (Optional)',
  },
];

export default exerciseLibrary;