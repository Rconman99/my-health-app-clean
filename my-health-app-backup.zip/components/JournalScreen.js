// 📄 Component: JournalScreen.js (FlatList-Based - Warning-Free)

import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
} from 'react-native';
import { loadFromStorage } from '../storage';

const JournalScreen = () => {
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    const fetchHistory = async () => {
      const stored = await loadFromStorage('history');
      if (stored) {
        const sorted = Object.entries(stored)
          .sort((a, b) => b[0].localeCompare(a[0]))
          .flatMap(([date, entry]) => entry.exercises.map((ex, i) => ({
            key: `${date}-${i}`,
            date,
            ...ex,
          })));
        setEntries(sorted);
      }
    };
    fetchHistory();
  }, []);

  const renderItem = ({ item, index }) => (
    <View key={item.key} style={styles.exerciseBox}>
      {(index === 0 || item.date !== entries[index - 1]?.date) && (
        <Text style={styles.date}>📅 {item.date}</Text>
      )}
      <Text style={styles.exerciseName}>{item.name}</Text>
      {item.superset && <Text style={styles.superset}>🔥 Superset {item.superset}</Text>}
      <Text style={styles.detail}>Rounds: {item.rounds || 1}</Text>
      <Text style={styles.detail}>Reps: {item.reps || '—'}</Text>
      {Array.isArray(item.weights) && (
        <Text style={styles.detail}>
          Weights: {item.weights.map((w, i) => `Round ${i + 1}: ${w}`).join(', ')}
        </Text>
      )}
      {item.notes && <Text style={styles.notes}>📝 {item.notes}</Text>}
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📔 Workout Journal</Text>
      <FlatList
        data={entries}
        keyExtractor={(item) => item.key}
        renderItem={renderItem}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  date: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 10,
    color: '#007bff',
  },
  exerciseBox: {
    marginBottom: 14,
    paddingBottom: 8,
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
  },
  exerciseName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  detail: {
    fontSize: 14,
    color: '#333',
  },
  superset: {
    fontSize: 14,
    fontWeight: '600',
    color: '#d63384',
  },
  notes: {
    fontStyle: 'italic',
    marginTop: 4,
    color: '#555',
  },
});

export default JournalScreen;
