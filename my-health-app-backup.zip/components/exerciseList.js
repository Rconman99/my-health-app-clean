// exerciseList.js

export const exerciseCategories = {
    Legs: [
      { name: 'Back Squat', emoji: '🏋️', level: 'Intermediate' },
      { name: 'Front Squat', emoji: '🏋️', level: 'Intermediate' },
      { name: 'Bodyweight Squats', emoji: '🙆', level: 'Beginner' },
      { name: 'Bulgarian Split Squat', emoji: '🦵', level: 'Intermediate' },
      { name: 'Goblet Squat', emoji: '🏋️‍♂️', level: 'Beginner' },
      { name: 'Trap Bar Deadlift', emoji: '⚰️', level: 'Beginner' },
      { name: 'Conventional Deadlift', emoji: '⚰️', level: 'Intermediate' },
      { name: 'Jump Squat', emoji: '🦘', level: 'Advanced' },
    ],
    Chest: [
      { name: 'Flat Bench Press', emoji: '🛏️', level: 'Intermediate' },
      { name: 'Incline Bench Press', emoji: '🛏️', level: 'Intermediate' },
      { name: 'Dumbbell Chest Flys', emoji: '👐', level: 'Intermediate' },
      { name: 'Standard Push-Ups', emoji: '🤸', level: 'Beginner' },
      { name: 'Diamond Push-Ups', emoji: '💎', level: 'Intermediate' },
      { name: 'Plyometric Push-Ups', emoji: '⚡️', level: 'Advanced' },
    ],
    Back: [
      { name: 'Pull-Ups', emoji: '🪜', level: 'Intermediate' },
      { name: 'Barbell Rows', emoji: '📦', level: 'Intermediate' },
      { name: 'Lat Pulldown', emoji: '🧲', level: 'Beginner' },
    ],
    Shoulders: [
      { name: 'Dumbbell Shoulder Press', emoji: '💪', level: 'Beginner' },
      { name: 'Lateral Raises', emoji: '🏹', level: 'Beginner' },
      { name: 'Military Press', emoji: '🎖️', level: 'Advanced' },
    ],
    Arms: [
      { name: 'Barbell Curls', emoji: '🔄', level: 'Intermediate' },
      { name: 'Hammer Curls', emoji: '🔨', level: 'Beginner' },
      { name: 'Tricep Dips', emoji: '⬇️', level: 'Intermediate' },
    ],
    Core: [
      { name: 'Crunches', emoji: '🥐', level: 'Beginner' },
      { name: 'Leg Raises', emoji: '🦵', level: 'Beginner' },
      { name: 'Planks', emoji: '📏', level: 'Beginner' },
      { name: 'Cable Woodchoppers', emoji: '🪓', level: 'Intermediate' },
    ],
    Cardio: [
      { name: 'Jump Rope', emoji: '🪢', level: 'Beginner' },
      { name: 'HIIT Sprints', emoji: '🏃‍♂️', level: 'Advanced' },
      { name: '2K Row', emoji: '🚣', level: 'Intermediate' },
      { name: 'Spin Bike', emoji: '🚴', level: 'Beginner' },
    ],
    Recovery: [
      { name: 'Foam Rolling', emoji: '🌀', level: 'Beginner' },
      { name: 'Dynamic Stretching', emoji: '🧘', level: 'Beginner' },
      { name: 'Walking', emoji: '🚶', level: 'Beginner' },
    ],
  };