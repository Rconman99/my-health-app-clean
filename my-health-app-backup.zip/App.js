import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { ThemeProvider } from './ThemeContext';

import DashboardScreen from './components/DashboardScreen';
import TrackerScreen from './components/TrackerScreen';
import ProfileForm from './components/ProfileForm';
import SuggestionsScreen from './components/SuggestionsScreen';
import EnhancedHistoryScreen from './components/EnhancedHistoryScreen';
import TrendsScreen from './components/TrendsScreen';
import SettingsScreen from './components/SettingsScreen';
import EditProfileScreen from './components/EditProfileScreen';
import WorkoutScreen from './components/WorkoutScreen';
import DiscoverScreen from './components/DiscoverScreen';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function InnerApp() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarActiveTintColor: '#007AFF',
          tabBarInactiveTintColor: 'gray',
        })}
      >
        <Tab.Screen name="Dashboard" component={DashboardScreen} />
        <Tab.Screen name="Workout" component={WorkoutScreen} />
        <Tab.Screen name="Tracker" component={TrackerScreen} />
        <Tab.Screen name="Profile" component={ProfileForm} />
        <Tab.Screen name="Suggestions" component={SuggestionsScreen} />
        <Tab.Screen name="Journal" component={EnhancedHistoryScreen} />
        <Tab.Screen name="Trends" component={TrendsScreen} />
        <Tab.Screen name="Settings" component={SettingsScreen} />
        <Tab.Screen name="Edit Profile" component={EditProfileScreen} />
        <Tab.Screen name="Discover" component={DiscoverScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <InnerApp />
    </ThemeProvider>
  );
}