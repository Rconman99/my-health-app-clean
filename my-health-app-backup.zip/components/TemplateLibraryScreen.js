// 📄 Component: TemplateLibraryScreen.js (Start of Template System)

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

const defaultTemplates = [
  {
    id: 'strength-6',
    name: '6-Week Strength Plan',
    weeks: 6,
    description: 'Focus on progressive overload for compound lifts.',
    goals: ['Muscle gain', 'Strength'],
  },
  {
    id: 'spartan-8',
    name: '8-Week Spartan Prep',
    weeks: 8,
    description: 'Endurance + functional workouts to prep for race.',
    goals: ['Endurance', 'Conditioning'],
  },
  {
    id: 'cut-4',
    name: '4-Week Summer Cut',
    weeks: 4,
    description: 'Fat loss-focused plan with HIIT & resistance.',
    goals: ['Fat loss', 'Shred'],
  },
];

const TemplateLibraryScreen = () => {
  const [templates, setTemplates] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    const loadTemplates = async () => {
      const stored = await AsyncStorage.getItem('customTemplates');
      const parsed = stored ? JSON.parse(stored) : [];
      setTemplates([...defaultTemplates, ...parsed]);
    };
    loadTemplates();
  }, []);

  const handleUseTemplate = (template) => {
    navigation.navigate('MultiWeekPlanner', { template });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>🏋️ Template Library</Text>
      <FlatList
        data={templates}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => handleUseTemplate(item)}>
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.meta}>{item.description}</Text>
            <Text style={styles.meta}>Weeks: {item.weeks}</Text>
            <Text style={styles.goalTags}>{item.goals.join(', ')}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#f9f9f9',
    padding: 14,
    borderRadius: 8,
    marginBottom: 12,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  meta: {
    fontSize: 14,
    color: '#555',
    marginTop: 4,
  },
  goalTags: {
    fontSize: 13,
    marginTop: 6,
    color: '#007bff',
  },
});

export default TemplateLibraryScreen;
