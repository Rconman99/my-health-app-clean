import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../ThemeContext';

const motivations = [
  'Cold builds resilience. Step into the discomfort.',
  'Your habits today are your hormones tomorrow.',
  'Discipline is biohacking at its core.',
  'Sunlight, movement, and stillness — nature’s stack.',
  'Small protocols lead to massive shifts.',
];

const DashboardScreen = () => {
  const { theme } = useTheme();
  const navigation = useNavigation();
  const [quote, setQuote] = useState('');
  const [latestLog, setLatestLog] = useState({});

  useEffect(() => {
    setQuote(motivations[Math.floor(Math.random() * motivations.length)]);

    const loadLog = async () => {
      const stored = await AsyncStorage.getItem('habitLog');
      if (!stored) return;
      const parsed = JSON.parse(stored);
      const dates = Object.keys(parsed).sort().reverse();
      const latest = dates.length ? parsed[dates[0]] : {};
      setLatestLog(latest);
    };

    loadLog();
  }, []);

  const navigate = (screen) => () => navigation.navigate(screen);

  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' });

  return (
    <ScrollView style={{ backgroundColor: theme.colors.background }} contentContainerStyle={styles.container}>
      <Text style={[styles.title, { color: theme.colors.text }]}>Welcome back 👋</Text>
      <Text style={[styles.subtitle, { color: theme.colors.text }]}>{today}</Text>

      <View style={[styles.card, { backgroundColor: theme.colors.card }]}>
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>🧠 Biohacker Motivation</Text>
        <Text style={[styles.quote, { color: theme.colors.text }]}>{quote}</Text>
      </View>

      <View style={[styles.card, { backgroundColor: theme.colors.card }]}>
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>📊 Recent Activity</Text>
        <Text style={{ color: theme.colors.text }}>
          {latestLog.workoutNotes ? '🏋️ Workout  ' : ''}
          {latestLog.plungeDuration ? '🧊 Plunge  ' : ''}
          {latestLog.redlightDuration ? '🔴 Red Light  ' : ''}
          {latestLog.peptideType ? '💉 Peptide  ' : ''}
          {latestLog.groundingDuration ? '🌍 Grounding  ' : ''}
          {latestLog.saunaDuration ? '🔥 Sauna  ' : ''}
          {Object.keys(latestLog).length === 0 ? 'No activity logged yet.' : ''}
        </Text>
      </View>

      <Text style={[styles.sectionTitle, { color: theme.colors.text, marginTop: 20 }]}>🧭 Discover</Text>
      <View style={styles.grid}>
        {['Workout', 'Tracker', 'Journal', 'Suggestions', 'Trends', 'Profile', 'Settings'].map((label) => (
          <TouchableOpacity
            key={label}
            style={[styles.gridItem, { backgroundColor: theme.colors.card }]}
            onPress={navigate(label)}
          >
            <Text style={{ color: theme.colors.text }}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingBottom: 80,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    elevation: 2,
  },
  quote: {
    fontStyle: 'italic',
    lineHeight: 20,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  gridItem: {
    width: '48%',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
});

export default DashboardScreen;