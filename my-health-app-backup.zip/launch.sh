#!/bin/bash
# 🚀 Auto-launch your app and VS Code

cd ~/my-health-app/my-health-app-clean || exit
code .
npx expo start --clear