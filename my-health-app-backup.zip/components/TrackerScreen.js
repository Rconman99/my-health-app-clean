import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Button,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTheme } from '../ThemeContext';

const activities = [
  'Workout',
  'Cold Plunge',
  'Red Light Therapy',
  'Peptide Dose',
  'Grounding',
];

const moodOptions = ['😄 Happy', '😐 Neutral', '😩 Tired', '😠 Stressed'];

const TrackerScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const [log, setLog] = useState({});
  const [mood, setMood] = useState('');
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadLog();
  }, []);

  const loadLog = async () => {
    try {
      const stored = await AsyncStorage.getItem('habitLog');
      const parsed = stored ? JSON.parse(stored) : {};
      setLog(parsed);
      const todayLog = parsed[today] || {};
      setMood(todayLog.mood || '');
    } catch (err) {
      console.error('Error loading log:', err);
    }
  };

  const toggleActivity = async (activity) => {
    const todayLog = log[today] || { habits: [], mood: '' };
    const updatedHabits = todayLog.habits?.includes(activity)
      ? todayLog.habits.filter((a) => a !== activity)
      : [...(todayLog.habits || []), activity];

    const newLog = {
      ...log,
      [today]: { ...todayLog, habits: updatedHabits, mood },
    };

    try {
      await AsyncStorage.setItem('habitLog', JSON.stringify(newLog));
      setLog(newLog);
    } catch (err) {
      console.error('Failed to save log:', err);
    }
  };

  const selectMood = async (selectedMood) => {
    const todayLog = log[today] || { habits: [], mood: '' };

    const newLog = {
      ...log,
      [today]: { ...todayLog, mood: selectedMood },
    };

    try {
      await AsyncStorage.setItem('habitLog', JSON.stringify(newLog));
      setLog(newLog);
      setMood(selectedMood);
    } catch (err) {
      console.error('Failed to save mood:', err);
    }
  };

  const isChecked = (activity) => log[today]?.habits?.includes(activity);

  return (
    <ScrollView style={{ backgroundColor: theme.colors.background }}>
      <View style={[styles.container]}>
        <Text style={[styles.title, { color: theme.colors.text }]}>Today's Tracker</Text>
        <Text style={[styles.date, { color: theme.colors.text }]}>{today}</Text>

        {activities.map((activity, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.button,
              {
                backgroundColor: isChecked(activity)
                  ? theme.colors.primary
                  : theme.colors.card,
                borderColor: theme.colors.border,
              },
            ]}
            onPress={() => toggleActivity(activity)}
          >
            <Text
              style={{
                color: isChecked(activity) ? '#fff' : theme.colors.text,
                textAlign: 'center',
                fontSize: 16,
                fontWeight: isChecked(activity) ? '600' : '400',
              }}
            >
              {activity}
            </Text>
          </TouchableOpacity>
        ))}

        <Text style={[styles.moodLabel, { color: theme.colors.text }]}>
          How are you feeling?
        </Text>
        <View style={styles.moodRow}>
          {moodOptions.map((m, index) => (
            <TouchableOpacity
              key={index}
              onPress={() => selectMood(m)}
              style={[
                styles.moodButton,
                {
                  backgroundColor: mood === m ? theme.colors.primary : theme.colors.card,
                  borderColor: theme.colors.border,
                },
              ]}
            >
              <Text
                style={{
                  fontSize: 18,
                  color: mood === m ? '#fff' : theme.colors.text,
                }}
              >
                {m}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ marginTop: 40 }}>
          <Button title="Go to Profile Setup" onPress={() => navigation.navigate('Profile')} />
          <View style={{ height: 15 }} />
          <Button title="Go to Your Plan" onPress={() => navigation.navigate('Suggestions')} />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 30,
    paddingBottom: 100,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 10,
  },
  date: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  button: {
    padding: 14,
    marginVertical: 8,
    borderWidth: 1,
    borderRadius: 10,
  },
  moodLabel: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 25,
    marginBottom: 10,
    textAlign: 'center',
  },
  moodRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  moodButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 10,
  },
});

export default TrackerScreen;