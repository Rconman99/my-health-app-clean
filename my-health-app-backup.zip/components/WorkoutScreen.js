import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import ExerciseCard from './ExerciseCard';
import { exerciseLibrary } from '../utils/exerciseLibrary';

const WorkoutScreen = () => {
  const [exercises, setExercises] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredExercises, setFilteredExercises] = useState([]);

  const handleAddExercise = (exerciseName) => {
    const newExercise = {
      id: Date.now().toString(),
      name: exerciseName,
      rounds: 1,
      weights: [''],
      reps: [''],
      notes: '',
      timer: 60,
    };
    setExercises([...exercises, newExercise]);
    setSearchTerm('');
    setFilteredExercises([]);
  };

  const handleSearchChange = (text) => {
    setSearchTerm(text);
    if (text.trim() === '') {
      setFilteredExercises([]);
    } else {
      const matches = exerciseLibrary.filter((name) =>
        name.toLowerCase().includes(text.toLowerCase())
      );
      setFilteredExercises(matches);
    }
  };

  const handleUpdateExercise = (updatedExercise) => {
    const updatedList = exercises.map((ex) =>
      ex.id === updatedExercise.id ? updatedExercise : ex
    );
    setExercises(updatedList);
  };

  const handleRemoveExercise = (id) => {
    setExercises(exercises.filter((ex) => ex.id !== id));
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>🏋️ Monday's Workout Plan</Text>

      <TextInput
        style={styles.input}
        placeholder="Add an exercise (e.g. Squat)"
        value={searchTerm}
        onChangeText={handleSearchChange}
      />

      {filteredExercises.map((item) => (
        <TouchableOpacity
          key={item}
          onPress={() => handleAddExercise(item)}
        >
          <Text style={styles.searchResult}>{item}</Text>
        </TouchableOpacity>
      ))}

      <TouchableOpacity onPress={() => handleAddExercise(searchTerm)}>
        <Text style={styles.add}>+ Add Exercise</Text>
      </TouchableOpacity>

      {exercises.map((exercise) => (
        <ExerciseCard
          key={exercise.id}
          exercise={exercise}
          onUpdate={handleUpdateExercise}
          onRemove={handleRemoveExercise}
        />
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 100,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: '#aaa',
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },
  searchResult: {
    padding: 8,
    backgroundColor: '#f0f0f0',
    borderBottomWidth: 1,
    borderColor: '#ddd',
  },
  add: {
    fontSize: 16,
    color: '#007bff',
    marginBottom: 20,
  },
});

export default WorkoutScreen;