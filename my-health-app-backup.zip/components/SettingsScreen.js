import React from 'react';
import { View, Text, Button, Alert, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SettingsScreen = ({ navigation }) => {
  const handleReset = () => {
    Alert.alert('Reset Everything?', 'This will delete all saved data.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reset All',
        style: 'destructive',
        onPress: async () => {
          try {
            await AsyncStorage.clear();
            Alert.alert('Data cleared. Restarting app...');
            navigation.reset({
              index: 0,
              routes: [{ name: 'Tracker' }],
            });
          } catch (err) {
            console.error('Reset failed:', err);
            Alert.alert('Reset failed.');
          }
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <Button title="Reset All App Data" color="#d00" onPress={handleReset} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 30,
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 20,
  },
});

export default SettingsScreen;