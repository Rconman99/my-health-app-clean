import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { loadFromStorage } from '../storage';

const protocols = ['Workout', 'Cold Plunge', 'Red Light', 'Grounding', 'Peptides', 'Sauna'];

const EnhancedHistoryScreen = () => {
  const [log, setLog] = useState({});

  useEffect(() => {
    const fetchLog = async () => {
      const data = await loadFromStorage('trackerLog');
      if (data) setLog(data);
    };
    fetchLog();
  }, []);

  const renderDay = (dayKey, dayLog) => {
    return (
      <View key={dayKey} style={styles.dayContainer}>
        <Text style={styles.date}>{dayKey}</Text>
        {protocols.map((protocol) => (
          <View key={protocol} style={styles.protocolBox}>
            <Text style={styles.protocolTitle}>{protocol}</Text>
            {dayLog[protocol] ? (
              typeof dayLog[protocol] === 'object' ? (
                Object.entries(dayLog[protocol]).map(([label, value]) => (
                  <Text key={label} style={styles.detail}>
                    {label}: {value}
                  </Text>
                ))
              ) : (
                <Text style={styles.detail}>{dayLog[protocol]}</Text>
              )
            ) : (
              <Text style={styles.missing}>Not logged</Text>
            )}
          </View>
        ))}
        {dayLog.notes && (
          <View style={styles.notesBox}>
            <Text style={styles.notesLabel}>📝 Day Notes:</Text>
            <Text style={styles.detail}>{dayLog.notes}</Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>📆 Journal Log</Text>
      {Object.entries(log).length === 0 ? (
        <Text style={styles.missing}>No logs found</Text>
      ) : (
        Object.entries(log)
          .sort((a, b) => new Date(b[0]) - new Date(a[0]))
          .map(([date, dayLog]) => renderDay(date, dayLog))
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  dayContainer: {
    marginBottom: 24,
    padding: 12,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
  },
  date: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#2a80ff',
  },
  protocolBox: {
    marginBottom: 8,
  },
  protocolTitle: {
    fontWeight: '600',
    fontSize: 16,
    color: '#333',
  },
  detail: {
    fontSize: 14,
    marginLeft: 10,
    color: '#444',
  },
  missing: {
    fontStyle: 'italic',
    color: 'gray',
    marginLeft: 10,
  },
  notesBox: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderColor: '#ddd',
  },
  notesLabel: {
    fontWeight: '600',
    marginBottom: 4,
  },
});

export default EnhancedHistoryScreen;